<?php defined('_JEXEC') or die;

/**
 * 
 */
class RestaurantControllerRestaurants extends JControllerForm {
	
}
