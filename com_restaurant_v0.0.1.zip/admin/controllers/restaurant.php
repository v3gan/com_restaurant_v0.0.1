<?php
defined('_JEXEC') or die;
/*
 * baseclass of JControllerForm at:
 *  /libraries/legacy/controller/form.php
 * check it out to see the fuctionality this class provides  
 */
class RestaurantControllerRestaurant extends JControllerForm
{

}